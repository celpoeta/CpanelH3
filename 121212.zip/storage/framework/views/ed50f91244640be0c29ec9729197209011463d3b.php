<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-sms-template')): ?>
<a class="btn btn-primary btn-sm" href="<?php echo e(route('sms-template.edit', $row->id)); ?>"
            data-bs-toggle="tooltip" data-bs-placement="bottom"
            data-bs-original-title="<?php echo e(__('Edit')); ?>" aria-label="<?php echo e(__('Edit')); ?>"><i
            class="ti ti-edit"></i></a>
<?php endif; ?>
<?php /**PATH C:\xampp8\htdocs\H3\resources\views/sms_template/action.blade.php ENDPATH**/ ?>