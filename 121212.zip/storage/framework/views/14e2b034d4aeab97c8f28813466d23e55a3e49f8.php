<script src="<?php echo e(asset('vendor/datatables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables/buttons.bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables/buttons.colVis.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables/buttons.server-side.js')); ?>"></script>
<?php /**PATH C:\xampp8\htdocs\H3\resources\views/layouts/includes/datatable_js.blade.php ENDPATH**/ ?>