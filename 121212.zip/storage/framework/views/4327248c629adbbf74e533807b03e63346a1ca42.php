<?php $__env->startSection('title', 'Create Category'); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <div class="col-md-12">
        <div class="page-header-title">
            <h4 class="m-b-10"><?php echo e(__('Edit Category')); ?></h4>
        </div>
        <ul class="breadcrumb">
            <li class="breadcrumb-item"><?php echo Html::link(route('home'), __('Dashboard'), []); ?></li>
            <li class="breadcrumb-item"><a href="<?php echo e(route('blogcategory.index')); ?>"><?php echo e(__('Blog Category')); ?></a></li>
            <li class="breadcrumb-item active"><?php echo e(__('Edit Category')); ?></li>
        </ul>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="card-body">
            <div class="row">
                <div class="col-md-4 m-auto">
                    <div class="card">
                        <div class="card-header">
                            <h5><?php echo e(__('Edit Category')); ?></h5>
                        </div>
                        <?php echo Form::model($category, [
                            'route' => ['blogcategory.update', $category->id],
                            'method' => 'PUT',
                            'enctype' => 'multipart/form-data',
                            'data-validate',
                        ]); ?>

                        <div class="card-body">
                            <div class="form-group">
                                <?php echo e(Form::label('name', __('Name'), ['class' => 'form-label'])); ?>

                                <?php echo Form::text('name', null, ['placeholder' => __('Enter name'), 'class' => 'form-control', 'required']); ?>

                            </div>
                            <div class="form-group">
                                <?php echo e(Form::label('icon', __('Icon'), ['class' => 'form-label'])); ?> *
                                <?php echo Form::file('icon', ['class' => 'form-control', 'required' => 'required']); ?>

                            </div>
                            <div class="form-group">
                                <?php echo e(Form::label('status', __('Status'), ['class' => 'form-label'])); ?>

                                <?php echo Form::select('status', ['1' => 'Active', '0' => 'Deactive'], $category->status, [
                                    'class' => 'form-select',
                                    'data-trigger',
                                ]); ?>

                            </div>
                        </div>
                        <div class="card-footer">
                            <div class="text-end">
                                <?php echo Html::link(route('blogcategory.index'), __('Cancel'), ['class' => 'btn btn-secondary']); ?>

                                <?php echo e(Form::button(__('Save'), ['type' => 'submit', 'class' => 'btn btn-primary'])); ?>

                            </div>
                        </div>
                        <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
        </div>
        <?php echo Form::close(); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<script src="<?php echo e(asset('assets/js/plugins/choices.min.js')); ?>"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var genericExamples = document.querySelectorAll('[data-trigger]');
            for (i = 0; i < genericExamples.length; ++i) {
                var element = genericExamples[i];
                new Choices(element, {
                    placeholderValue: 'This is a placeholder set in the config',
                    searchPlaceholderValue: 'This is a search placeholder',
                });
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8\htdocs\H3\resources\views/blogcategory/edit.blade.php ENDPATH**/ ?>