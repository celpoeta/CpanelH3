<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-mailtemplate')): ?>
    <a href="<?php echo e(route('mailtemplate.edit', $mailtemple->id)); ?>" class="btn btn-primary btn-sm" data-toggle="tooltip"
        data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="<?php echo e(__('Edit')); ?>"><i
            class="ti ti-edit"></i> </a>
<?php endif; ?>

<?php /**PATH C:\xampp8\htdocs\H3\resources\views/mailtemplete/action.blade.php ENDPATH**/ ?>