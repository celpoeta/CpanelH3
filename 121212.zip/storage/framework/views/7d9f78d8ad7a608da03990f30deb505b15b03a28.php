<?php echo e(Form::open([
    'route' => 'event.store',
    'method' => 'POST',
    'enctype' => 'multipart/form-data',
    'data-validate',
])); ?>

<div class="modal-body">
    <div class="row">
        <div class="col-md-12 col-sm-12 col-lg-12 col-xl-12">
            <div class="form-group">
                <?php if(Auth::user()->type == 'Admin'): ?>
                <?php echo e(Form::label('user[]', __('User'), ['class' => 'form-label'])); ?>

                <?php echo e(Form::select('user[]', $users, null, ['class' => 'form-select', 'required','id' => 'user', 'multiple', 'data-trigger'])); ?>

                <?php endif; ?>
            </div>
        </div>
        <div class="col-md-12 col-sm-12 col-lg-12 col-xl-12">
            <div class="form-group">
                <?php echo e(Form::label('title', __('Event Title'), ['class' => 'form-label'])); ?>

                <?php echo e(Form::text('title', null, ['class' => 'form-control ', 'placeholder' => __('Enter event title')])); ?>

            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <?php echo e(Form::label('start_date', __('Start Date'), ['class' => 'form-label'])); ?>

                <?php echo e(Form::text('start_date', $start_date, ['class' => 'form-control ', 'placeholder' => __('Enter start date'), 'id' => 'start_date'])); ?>

            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <?php echo e(Form::label('end_date', __('End Date'), ['class' => 'form-label'])); ?>

                <?php echo e(Form::text('end_date', $end_date, ['class' => 'form-control ', 'placeholder' => __('Enter end date'), 'id' => 'end_date'])); ?>

            </div>
        </div>
        <div class="col-md-12 col-sm-12 col-lg-12 col-xl-12">
            <div class="form-group">
                <?php echo e(Form::label('color', __('Event Select Color'), ['class' => 'form-label d-block mb-3'])); ?>

                <div class="btn-group-toggle btn-group-colors event-tag" data-toggle="buttons">
                    <label class="p-3 btn bg-info"><input type="radio" name="color" id="color" value="event-info" checked
                            class="d-none"></label>
                    <label class="p-3 btn bg-warning"><input type="radio" name="color" id="color" value="event-warning"
                            class="d-none"></label>
                    <label class="p-3 btn bg-danger"><input type="radio" name="color" id="color" value="event-danger"
                            class="d-none"></label>
                    <label class="p-3 btn bg-success"><input type="radio" name="color" id="color" value="event-success"
                            class="d-none"></label>
                    <label class="p-3 btn bg-primary"><input type="radio" name="color" id="color" class="d-none"
                            value="event-primary"></label>
                </div>
            </div>
        </div>
        <div class="form-group">
            <?php echo e(Form::label('description', __('Event Description'), ['class' => 'form-label'])); ?>

            <?php echo e(Form::textarea('description', null, ['class' => 'form-control', 'placeholder' => __('Enter event description'), 'rows' => '5'])); ?>

        </div>
        <?php if(Utility::getsettings('google_calendar_enable') && Utility::getsettings('google_calendar_enable') == 'on'): ?>
            <div class="form-group col-md-12">
                <?php echo e(Form::label('switch-shadow', __('Synchronize in Google Calendar ?'), ['class' => 'form-label'])); ?>

                <div class="form-switch float-end">
                    <input type="checkbox" class="mt-2 form-check-input" name="synchronize_type" id="switch-shadow"
                        value="google_calender">
                    <label class="form-check-label" for="switch-shadow"></label>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>
<div class="modal-footer">
    <input type="button" value="Cancel" class="btn btn-secondary" data-bs-dismiss="modal">
    <input type="submit" value="<?php echo e(__('Save')); ?>" class="btn btn-primary">
</div>
<?php echo e(Form::close()); ?>

<?php /**PATH C:\xampp8\htdocs\H3\resources\views/event/create.blade.php ENDPATH**/ ?>