<link rel="stylesheet" href="<?php echo e(asset('vendor/datatables/datatables.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('vendor/datatables/buttons.bootstrap.min.css')); ?>">
<?php /**PATH C:\xampp8\htdocs\H3\resources\views/layouts/includes/datatable_css.blade.php ENDPATH**/ ?>