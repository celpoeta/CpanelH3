<?php
    use App\Models\Form;
    use App\Models\Booking;
    $user = \Auth::user();
    $currantLang = $user->currentLanguage();
    $languages = Utility::languages();
    $role_id = $user->roles->first()->id;
    $user_id = $user->id;
    if (Auth::user()->type == 'Admin') {
        $forms = Form::all();
        $all_forms = Form::all();
        $bookings = Booking::all();
    } else {
        $forms = Form::select(['forms.*'])->where(function ($query) use ($role_id, $user_id) {
            $query
                ->whereIn('forms.id', function ($query1) use ($role_id) {
                    $query1
                        ->select('form_id')
                        ->from('assign_forms_roles')
                        ->where('role_id', $role_id);
                })
                ->OrWhereIn('forms.id', function ($query1) use ($user_id) {
                    $query1
                        ->select('form_id')
                        ->from('assign_forms_users')
                        ->where('user_id', $user_id);
                });
        });
        $bookings = Booking::all();
        $all_forms = Form::select('id', 'title')
            ->where('created_by', $user->id)
            ->get();
    }
    $bookings = $bookings->all();
?>
<nav class="dash-sidebar light-sidebar <?php echo e($user->transprent_layout == 1 ? 'transprent-bg' : ''); ?>">
    <div class="navbar-wrapper">
        <div class="m-header">
            <a href="<?php echo e(route('home')); ?>" class="text-center b-brand">
                <!-- ========   change your logo hear   ============ -->
                <?php if($user->dark_layout == 1): ?>
                    <img src="<?php echo e(Utility::getsettings('app_logo') ? Storage::url('appLogo/app-logo.png') : Storage::url('appLogo/78x78.png')); ?>"
                        class="app-logo" />
                <?php else: ?>
                    <img src="<?php echo e(Utility::getsettings('app_dark_logo') ? Storage::url('appLogo/app-dark-logo.png') : Storage::url('appLogo/78x78.png')); ?>"
                        class="app-logo" />
                <?php endif; ?>
            </a>
        </div>
        <div class="navbar-content">
            <ul class="dash-navbar d-block">
                <li class="dash-item dash-hasmenu <?php echo e(request()->is('/') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('home')); ?>" class="dash-link"><span class="dash-micon"><i
                                class="ti ti-home"></i></span>
                        <span class="dash-mtext custom-weight"><?php echo e(__('Dashboard')); ?></span></a>
                </li>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-dashboardwidget')): ?>
                    <li class="dash-item dash-hasmenu <?php echo e(request()->is('index-dashboard*') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('index.dashboard')); ?>" class="dash-link"><span class="dash-micon"><i
                                    class="ti ti-square"></i></span>
                            <span class="dash-mtext custom-weight"><?php echo e(__('Dashboard Widgets')); ?></span></a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-blog')): ?>
                <li class="dash-item dash-hasmenu <?php echo e(request()->is('zoos*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('zoos.index')); ?>" class="dash-link">
                        <span class="dash-micon">
                            <i class="ti ti-map"></i>
                        </span>
                        <span class="dash-mtext"><?php echo e(__('Zoos')); ?>

                        </span>
                    </a>
                </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage-user', 'manage-role'])): ?>
                    <li
                        class="dash-item dash-hasmenu <?php echo e(request()->is('users*') || request()->is('roles*') ? 'active dash-trigger' : 'collapsed'); ?>">
                        <a href="#!" class="dash-link"><span class="dash-micon"><i
                                    class="ti ti-layout-2"></i></span><span
                                class="dash-mtext"><?php echo e(__('User Management')); ?></span><span class="dash-arrow"><i
                                    data-feather="chevron-right"></i></span></a>
                        <ul class="dash-submenu">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-user')): ?>
                                <li class="dash-item <?php echo e(request()->is('users*') ? 'active' : ''); ?>">
                                    <a class="dash-link" href="<?php echo e(route('users.index')); ?>"><?php echo e(__('Users')); ?></a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-role')): ?>
                                <li class="dash-item <?php echo e(request()->is('roles*') ? 'active' : ''); ?>">
                                    <a class="dash-link" href="<?php echo e(route('roles.index')); ?>"><?php echo e(__('Roles')); ?></a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage-blog', 'manage-category'])): ?>
                    <li
                        class="dash-item dash-hasmenu <?php echo e(request()->is('blogs*') || request()->is('blogcategory*') ? 'active dash-trigger' : 'collapsed'); ?>">
                        <a href="#!" class="dash-link">
                            <span class="dash-micon">
                                <i class="ti ti-forms"></i>
                            </span>
                            <span class="dash-mtext"><?php echo e(__('Blog')); ?></span>
                            <span class="dash-arrow"><i data-feather="chevron-right"></i>
                            </span>
                        </a>
                        <ul class="dash-submenu">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-blog')): ?>
                                <li class="dash-item <?php echo e(request()->is('blogs*') ? 'active' : ''); ?>">
                                    <a class="dash-link" href="<?php echo e(route('blogs.index')); ?>"><?php echo e(__('Blogs')); ?></a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-category')): ?>
                                <li class="dash-item <?php echo e(request()->is('blogcategory*') ? 'active' : ''); ?>">
                                    <a class="dash-link" href="<?php echo e(route('blogcategory.index')); ?>"><?php echo e(__('Categories')); ?></a>
                                </li>
                            <?php endif; ?>

                        </ul>
                    </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage-event'])): ?>
                    <li class="dash-item dash-hasmenu <?php echo e(request()->is('event*') ? 'active' : ''); ?>">
                        <a class="dash-link" href="<?php echo e(route('event.index')); ?>"><span class="dash-micon">
                                <i class="ti ti-calendar"></i></span>
                            <span class="dash-mtext"><?php echo e(__('Event Calender')); ?></span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage-chat'])): ?>
                    <?php if(setting('pusher_status') == '1'): ?>
                        <li
                            class="dash-item dash-hasmenu <?php echo e(request()->is('chat*') ? 'active dash-trigger' : 'collapsed'); ?>">
                            <a href="#!" class="dash-link"><span class="dash-micon"><i
                                        class="ti ti-table"></i></span><span
                                    class="dash-mtext"><?php echo e(__('Support')); ?></span><span class="dash-arrow"><i
                                        data-feather="chevron-right"></i></span></a>
                            <ul class="dash-submenu">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-chat')): ?>
                                    <li class="dash-item">
                                        <a class="dash-link" href="<?php echo e(route('chats')); ?>"><?php echo e(__('Chats')); ?></a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage-mailtemplate', 'manage-sms-template', 'manage-language', 'manage-setting'])): ?>
                    <li
                        class="dash-item dash-hasmenu <?php echo e(request()->is('mailtemplate*') || request()->is('sms-template*') || request()->is('manage-language*') || request()->is('create-language*') || request()->is('settings*') ? 'active dash-trigger' : 'collapsed'); ?> || <?php echo e(request()->is('create-language*') || request()->is('settings*') ? 'active' : ''); ?>">
                        <a href="#!" class="dash-link"><span class="dash-micon"><i
                                    class="ti ti-apps"></i></span><span
                                class="dash-mtext"><?php echo e(__('Account Setting')); ?></span><span class="dash-arrow"><i
                                    data-feather="chevron-right"></i></span></a>
                        <ul class="dash-submenu">

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-setting')): ?>
                                <li class="dash-item <?php echo e(request()->is('settings*') ? 'active' : ''); ?>">
                                    <a class="dash-link" href="<?php echo e(route('settings')); ?>"><?php echo e(__('Settings')); ?></a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>

            </ul>
        </div>
    </div>
</nav>
<?php /**PATH C:\xampp8\htdocs\H3\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>